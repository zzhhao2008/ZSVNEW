<nav class="navbar  navbar-inverse navbar-default navbar-fixed-top" role="navigation">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse">
                    <span class="sr-only">切换导航</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/">DEV-Env</a>
            </div>
            <div class="collapse navbar-collapse" id="example-navbar-collapse">
                <ul class="nav navbar-nav">
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <?php if (isset($user)) { ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <img src="<?php echo $hp ?>" class="navbarsicon">
                                <?php echo $user['name'] ?> <b class="caret"></b>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="/index.php/u/center"><span class="glyphicon glyphicon-user"></span><?php echo lan('user_center') ?></a></li>
                                <li><a href="/index.php/u/logout?logout=1"><span class="glyphicon glyphicon-log-out"></span><?php echo lan('log_out') ?></a></li>
                            </ul>
                        </li>
                    <?php } else { ?>
                        <li><a href="#" data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-log-in"></span> <?php echo lan('login') ?></a></li>
                    <?php } ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <span class="glyphicon glyphicon-globe"></span>
                            <?php echo lan('language') ?> <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="/index.php?languageset=zh-cn">简体中文</a></li>
                            <li><a href="/index.php?languageset=en">English</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <script>
        function bigimg(id) {
        var imgbox = document.getElementById(id);
        var bigimgbox = document.createElement("div");
        bigimgbox.classList.add("img-big");
        var bigimg = document.createElement("img");
        bigimg.src = imgbox.src;
        bigimgbox.appendChild(bigimg);
        document.body.appendChild(bigimgbox);
        bigimgbox.onclick = function() {
            document.body.removeChild(bigimgbox);
        };
    }
    </script>