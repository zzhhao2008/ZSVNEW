<?php
return array(
    "welcome" => "Welcome To ZSV-New!",
    "idxdesc" => "Where is the 'new'?
        <blockquote>
    1. Global PathINFO<br>
    2. Multi-language support<br>
    3. Modular function<br>
    4. The code is open source
</blockquote>",
    "language" => "language/语言",
    "login" => "Login",
    "uid" => "User-ID",
    "pas" => "Password",
    "email" => "Email",
    "tel" => "Tel",
    'logup' => "Log Up",
    "user_center"=>"User_Center",
    "log_out"=>"LOG Out"
);
