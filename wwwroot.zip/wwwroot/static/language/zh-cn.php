<?php
    return array(
        "welcome"=>"欢迎来到ZSV-New开发环境",
        "idxdesc"=>"DEV ENV",
        "language"=>"语言/language",
        "login"=>"登录",
        "ERR404"=>"<h1>404 Not Found</h1>你从哪里进来的？QAQ",
        "uid"=>"账号",
        "pas"=>"密码",
        "email"=>"邮箱",
        "tel"=>"电话",
        'logup'=>"注册",
        "user_center"=>"个人中心",
        "log_out"=>"退出登录",
        "set_theme"=>"主题设置",
        'User_Avatar'=>"更改头像",
        "User_Zone"=>"空间",
        "setting"=>"设置",
        "view"=>"查看",
        "visit"=>"访问",
        "done"=>"确定"
    );