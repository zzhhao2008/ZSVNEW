<?php
if (empty($_POST['uid'])) {
    $mes = "输入任意ID";
} else {
    $user=array(
        "name"=>"Dev",
        ""
    );
    setcookie("pass","123", time() + 24 * 3600, "/");
    $mes = "登录成功！";
}
echo "<script>alert('" . $mes . "');location.href=window.location</script>";
unset($mes);
unset($id);
unset($StrConents);
