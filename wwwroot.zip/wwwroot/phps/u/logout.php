<?php
    setcookie("uname", "", time() - 24 * 3600, "/");
    setcookie("uid", "", time() - 24 * 3600, "/");
    setcookie("pas", "", time() - 24 * 3600, "/");
?>
<h1>你已成功退出登录！</h1>
<a href="/">返回</a>