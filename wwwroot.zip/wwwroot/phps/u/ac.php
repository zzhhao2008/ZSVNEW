<?php
function jsr($fun)
{
    echo "<script>" . $fun . "</script>";
}
if($_COOKIE['pass']){
    $user=array(
        "name"=>"Dev",
        ""
    );
}else{
    unset($user);
}
