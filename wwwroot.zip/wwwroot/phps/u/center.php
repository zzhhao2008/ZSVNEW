<?php
checklogin();
?>
<img src="<?php echo $hp ?>">
<h1><span>Hi! <?php echo $user["name"] ?></span></h1>
<?php echo $mst ?>
<hr>