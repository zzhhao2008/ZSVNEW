<?php
function checklogin(){
    global $user;
    if(!isset($user)){
        echo "<script>alert('请先登录！')</script>";
        exit;
    }
}
/* languagemodel*/
if ($_COOKIE['language']) {
    $lfp = "./static/language/" . $_COOKIE['language'] . ".php";
    if (file_exists($lfp)) {
        $language = require $lfp;
    } else {
        $language = require "./static/language/zh-cn.php";
    }
} else {
    $language = require "./static/language/zh-cn.php";
}
if ($_GET['languageset']) {
    setcookie("language", $_GET['languageset'], time() + 3600 * 24 * 365 * 5);
    header("location:/");
}
function lan($tx)
{
    global $language;
    if ($language[$tx]) return $language[$tx];
    else {
        return $tx;
    }
}
/*加载自定义CSS*/
$hp="/icon.jpg";
