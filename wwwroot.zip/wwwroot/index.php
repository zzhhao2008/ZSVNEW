<!DOCTYPE html>
<html>

<head>
    <link rel='shortcut icon' href="/icon.png">
    <script src="/static/js/jquery-3.7.0.min.js"></script>
    <script src="/static/bootstrap-4.4.1-dist/js/bootstrap.js"></script>
    <link rel="stylesheet" href="/static/bootstrap-3.4.1-dist/css/bootstrap.css" th:href="@{/lib/semantic/dist/semantic.min.css}">
    <link rel="stylesheet" href="/static/css/dark.css" th:href="@{/lib/semantic/dist/semantic.min.css}">
    <script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ZSV - New -DEV</title>
    <style>
        body>.container>.index {
            text-align: center;
            font-size: 20px;
        }


        form input,
        form textarea {
            color: black
        }
    </style>
</head>

<?php
if ($_POST['uid']) {
    include "phps/u/log.php";
}
include "phps/u/ac.php";

if ($_GET['logout'] == 1) {
    include "phps/u/logout.php";
    exit;
}
include "phps/stdfuc.php";
?>
<style>
    body {
        background-attachment: fixed;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        overflow-y: scroll;
    }

    body::before {
        content: '';
        position: fixed;
        top: 0;
        left: 0;
        height: 100vh;
        width: 100%;
        background: rgba(0, 0, 0, 0.3);
        z-index: -1;
    }
    form * {
        color: #000;
    }
</style>

<body>
    <?php include './static/headbar.php' ?>
    <?php if (!isset($user)) include "./phps/loginmodal" ?>
    <div class="container">
        <?php
        if ($_SERVER['PATH_INFO']) {
            $funcp = "phps/" . $_SERVER["PATH_INFO"] . ".php";
            if (!file_exists($funcp) || is_dir($funcp)) {
                echo lan('ERR404');
            } else {
                include $funcp;
            }
            unset($funcp);
        } else {
        ?>
            <div class="index">
                <h1><?php echo lan('welcome') ?></h1>
                <p>
                    <?php echo lan('idxdesc');include "./temp.html" ?>
                    
                </p>
            </div>
        <?php } ?>
    </div>
</body>

</html>